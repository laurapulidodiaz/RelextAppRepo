"""Unit tests for special node behaviours."""
